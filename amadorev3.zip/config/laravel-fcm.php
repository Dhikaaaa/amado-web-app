<?php

return [

    /**
     * Set your FCM Server Key
     * Change to yours
     */

    'server_key' => env('FCM_SERVER_KEY', 'AAAAV_VvmBA:APA91bGge5fRJQTsAtz5NxK-5wXbxLlQAnLCz3v67Rjtgr-UX7B7nrIz9bahqWPAQ6UieqjixuXTknA-7hN94Lw6gtUdvOJAGR1eZk3_FXaF5tHjkuJ3pCL2yM7o4Fm82fpLM-AEZISv'),

];
