

<?php $__env->startSection('title', 'Pengembalian Buku'); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="row">
		<div class="col-sm-5 mb-4">
			<div class="card shadow">
				<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('loan.return-search', [])->html();
} elseif ($_instance->childHasBeenRendered('jzNBE0T')) {
    $componentId = $_instance->getRenderedChildComponentId('jzNBE0T');
    $componentTag = $_instance->getRenderedChildComponentTagName('jzNBE0T');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jzNBE0T');
} else {
    $response = \Livewire\Livewire::mount('loan.return-search', []);
    $html = $response->html();
    $_instance->logRenderedChild('jzNBE0T', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
			</div>
		</div>
		<div class="col-sm-7">
			<div class="card shadow">
				<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('loan.return-form', [])->html();
} elseif ($_instance->childHasBeenRendered('fSiwStr')) {
    $componentId = $_instance->getRenderedChildComponentId('fSiwStr');
    $componentTag = $_instance->getRenderedChildComponentTagName('fSiwStr');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fSiwStr');
} else {
    $response = \Livewire\Livewire::mount('loan.return-form', []);
    $html = $response->html();
    $_instance->logRenderedChild('fSiwStr', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
			</div>
		</div>
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YOFAN\Desktop\front-end\perpus\resources\views/loan/return.blade.php ENDPATH**/ ?>