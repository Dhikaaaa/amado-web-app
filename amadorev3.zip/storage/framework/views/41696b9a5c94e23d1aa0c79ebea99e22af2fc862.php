<form wire:submit.prevent="returnBook">
	<?php echo csrf_field(); ?>
	<div class="card-header py-3">
		<h2 class="h6 m-0 font-weight-bold text-primary">Data Peminjaman</h2>
	</div>
	<div class="card-body">
		<div class="form-group">
			<label>Judul Buku</label>
			<input type="text" class="form-control" placeholder="Judul Buku" value="<?php echo e($loan ? $loan->book->title : ''); ?>" disabled>
		</div>
		<div class="form-group">
			<label>Peminjam</label>
			<input type="text" class="form-control" placeholder="Peminjam" value="<?php echo e($loan ? $loan->member->name : ''); ?>" disabled>
		</div>
		<div class="form-row">
			<div class="col-sm-6">
				<div class="form-group">
					<label>Terlambat</label>
					<input type="text" class="form-control" placeholder="Terlambat" value="<?php if(isset($late)): ?><?php echo e($late); ?> Hari <?php endif; ?>" disabled>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group">
					<label>Denda</label>
					<div class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text">Rp</span>
						</div>
						<input type="text" class="form-control" placeholder="Denda" value="<?php if(isset($fine)): ?><?php echo e($fine); ?> <?php endif; ?>" disabled>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="card-footer">
		<button class="btn btn-primary shadow submit" type="submit">Kembalikan</button>
		<a href="<?php echo e(route('loan.index')); ?>" class="btn btn-secondary shadow">Batal</a>
	</div>
</form>

<?php $__env->startPush('js'); ?>
	<script>
		document.querySelector('.submit').disabled = true;
	</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\YOFAN\Desktop\front-end\perpus\resources\views/livewire/loan/return-form.blade.php ENDPATH**/ ?>