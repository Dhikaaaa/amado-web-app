<div class="col-sm-6 mx-auto">
	<?php if(session()->has('success')): ?>
		<div class="alert alert-success alert-dismissible">
		  <span><?php echo e(session('success' )); ?></span>
		  <button class="close" data-dismiss="alert">&times;</button>
		</div>
	<?php endif; ?>
	<div class="card shadow">
	<form wire:submit.prevent="save">
		<?php echo csrf_field(); ?>
		<div class="card-header py-3">
			<h2 class="h6 m-0 font-weight-bold text-primary">Pengaturan</h2>
		</div>
		<div class="card-body">
			<div class="form-group">
				<label>Nama Aplikasi</label>
				<input type="text" class="form-control <?php $__errorArgs = ['setting.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="setting.name" placeholder="Nama Aplikasi" autofocus>

				<?php $__errorArgs = ['setting.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<span class="invalid-feedback"><?php echo e($message); ?></span>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div class="form-group">
				<label>Nominal Denda (Per Hari)</label>
				<div class="input-group">
					<div class="input-group-prepend">
						<span class="input-group-text">Rp</span>
					</div>
					<input type="text" class="form-control <?php $__errorArgs = ['setting.fine'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="setting.fine" placeholder="Denda">

					<?php $__errorArgs = ['setting.fine'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback"><?php echo e($message); ?></span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>
		</div>
		<div class="card-footer">
			<button class="btn btn-primary shadow" type="submit">Simpan</button>
			<a href="<?php echo e(route('member.index')); ?>" class="btn btn-secondary shadow">Batal</a>
		</div>
	</form>
	</div>
</div><?php /**PATH C:\Users\YOFAN\Desktop\PA\amado\resources\views/livewire/setting.blade.php ENDPATH**/ ?>