

<?php $__env->startSection('title', 'Rak'); ?>

<?php $__env->startSection('content'); ?>
	
	<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('rack.data', [])->html();
} elseif ($_instance->childHasBeenRendered('BqnJdG7')) {
    $componentId = $_instance->getRenderedChildComponentId('BqnJdG7');
    $componentTag = $_instance->getRenderedChildComponentTagName('BqnJdG7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BqnJdG7');
} else {
    $response = \Livewire\Livewire::mount('rack.data', []);
    $html = $response->html();
    $_instance->logRenderedChild('BqnJdG7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YOFAN\Desktop\PA\amado\resources\views/rack.blade.php ENDPATH**/ ?>