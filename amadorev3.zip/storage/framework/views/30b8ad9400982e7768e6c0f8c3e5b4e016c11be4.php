

<?php $__env->startSection('title', 'Pengaturan'); ?>

<?php $__env->startSection('content'); ?>
	
	<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('setting', [])->html();
} elseif ($_instance->childHasBeenRendered('d1ksaAx')) {
    $componentId = $_instance->getRenderedChildComponentId('d1ksaAx');
    $componentTag = $_instance->getRenderedChildComponentTagName('d1ksaAx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('d1ksaAx');
} else {
    $response = \Livewire\Livewire::mount('setting', []);
    $html = $response->html();
    $_instance->logRenderedChild('d1ksaAx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YOFAN\Desktop\PA\amado\resources\views/setting.blade.php ENDPATH**/ ?>