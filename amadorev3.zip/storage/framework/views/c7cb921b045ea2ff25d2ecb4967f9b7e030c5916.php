

<?php $__env->startSection('title', 'Peminjaman Baru'); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="col-md-9 col-lg-6 mx-auto">
		<div class="card shadow">
		<form action="<?php echo e(route('loan.store')); ?>" method="post" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<div class="card-header py-3">
				<h2 class="h6 m-0 font-weight-bold text-primary">Peminjaman Baru</h2>
			</div>
			<div class="card-body">
				<div class="form-group">
					<label>Kode Buku</label>
					<select class="form-control custom-select <?php $__errorArgs = ['book_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="book_id"></select>

					<?php $__errorArgs = ['book_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback"><?php echo e($message); ?></span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
				<div class="form-group">
					<label>Judul Buku</label>
					<input type="text" class="form-control" placeholder="Judul Buku" name="title" disabled>
				</div>
				<div class="form-group">
					<label>Tanggal Pinjam</label>
					<input type="date" class="form-control <?php $__errorArgs = ['create_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="create_date" value="<?php echo e(date('Y-m-d')); ?>" placeholder="Tanggal Pinjam">

					<?php $__errorArgs = ['create_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback"><?php echo e($message); ?></span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
				<div class="form-group">
					<label>Tanggal Kembali</label>
					<input type="date" class="form-control <?php $__errorArgs = ['return_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="return_date" value="<?php echo e(old('return_date')); ?>" placeholder="Tanggal Kembali">

					<?php $__errorArgs = ['return_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback"><?php echo e($message); ?></span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
				<div class="form-group">
					<label>Anggota</label>
					<select class="form-control custom-select <?php $__errorArgs = ['member_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="member_id"></select>

					<?php $__errorArgs = ['member_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback"><?php echo e($message); ?></span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>
			<div class="card-footer">
				<button class="btn btn-primary shadow" type="submit">Tambah</button>
				<a href="<?php echo e(route('loan.index')); ?>" class="btn btn-secondary shadow">Batal</a>
			</div>
		</form>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('sbadmin/vendor/select2/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
	<script src="<?php echo e(asset('sbadmin/vendor/select2/js/select2.min.js')); ?>"></script>
	<script>
		$(function () {
			$('[name=book_id]').select2({
				placeholder: 'Kode Buku',
				ajax: {
					url: '<?php echo e(route('book.search')); ?>',
					type: 'post',
					data: params => ({
						code: params.term,
						_token: '<?php echo e(csrf_token()); ?>'
					}),
					processResults: res => ({
						results: res
					}),
					cache: true
				}
			})
			$('[name=member_id]').select2({
				placeholder: 'Anggota',
				ajax: {
					url: '<?php echo e(route('member.search')); ?>',
					type: 'post',
					data: params => ({
						name: params.term,
						_token: '<?php echo e(csrf_token()); ?>'
					}),
					processResults: res => ({
						results: res
					}),
					cache: true
				}
			})
			$('[name=book_id]').on('select2:select', function (e) {
				const title = e.params.data.title

				$('[name=title]').val(title)
			})
		})
	</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YOFAN\Desktop\front-end\perpus\resources\views/loan/create.blade.php ENDPATH**/ ?>