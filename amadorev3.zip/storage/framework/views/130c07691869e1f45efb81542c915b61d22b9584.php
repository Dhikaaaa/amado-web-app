<form wire:submit.prevent="extendBook">
	<?php echo csrf_field(); ?>
	<div class="card-header py-3">
		<h2 class="h6 m-0 font-weight-bold text-primary">Data Peminjaman</h2>
	</div>
	<div class="card-body">
		<div class="form-group">
			<label>Judul Buku</label>
			<input type="text" class="form-control" placeholder="Judul Buku" value="<?php echo e($loan ? $loan->book->title : ''); ?>" disabled>
		</div>
		<div class="form-group">
			<label>Peminjam</label>
			<input type="text" class="form-control" placeholder="Peminjam" value="<?php echo e($loan ? $loan->member->name : ''); ?>" disabled>
		</div>
		<div class="form-row">
			<div class="col-sm-6">
				<div class="form-group">
					<label>Tanggal Kembali</label>
					<input type="text" class="form-control" placeholder="Tanggal Kembali" value="<?php echo e($loan ? $loan->return_local : ''); ?>" disabled>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group">
					<label>Terlambat</label>
					<input type="text" class="form-control" placeholder="Terlambat" value="<?php if(isset($late)): ?><?php echo e($late); ?> Hari <?php endif; ?>" disabled>
				</div>
			</div>
		</div>
		<div class="form-group">
			<label>Perpanjang Hingga</label>
			<input type="date" class="form-control <?php $__errorArgs = ['extend'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Perpanjang Hingga" wire:model="extend">

			<?php $__errorArgs = ['extend'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<span class="invalid-feedback"><?php echo e($message); ?></span>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
	</div>
	<div class="card-footer">
		<button class="btn btn-primary shadow submit" type="submit">Perpanjang</button>
		<a href="<?php echo e(route('loan.index')); ?>" class="btn btn-secondary shadow">Batal</a>
	</div>
</form>

<?php $__env->startPush('js'); ?>
	<script>
		document.querySelector('.submit').disabled = true;
	</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\YOFAN\Desktop\front-end\perpus\resources\views/livewire/loan/extend-form.blade.php ENDPATH**/ ?>