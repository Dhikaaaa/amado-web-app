<div class="card shadow">
	<div class="card-header py-3">
		<h2 class="card-title h6 font-weight-bold text-primary m-0">Tambah Rak</h2>
	</div>
	<div class="card-body">
		<form wire:submit.prevent="store">
			<div class="form-group">
				<label>Nama</label>
				<input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="name" placeholder="Nama" autofocus>

				<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<span class="invalid-feedback"><?php echo e($message); ?></span>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<button class="btn btn-primary shadow" type="submit">Tambah</button>
		</form>
	</div>
</div><?php /**PATH C:\Users\YOFAN\Desktop\front-end\perpus\resources\views/livewire/rack/create.blade.php ENDPATH**/ ?>