

<?php $__env->startSection('title', 'Detail Buku'); ?>

<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-lg-6 mb-4">
			<img src="<?php echo e($book->photoSrc); ?>" class="img-fluid rounded">
		</div>
		<div class="col-lg-6">
			<div class="card shadow">
				<div class="card-header py-3">
					<h2 class="h6 m-0 font-weight-bold text-primary">Data Buku</h2>
				</div>
				<div class="card-body">
					<dl class="row">
						<dt class="col-4">Judul</dt>
						<dd class="col-1">:</dd>
						<dd class="col-7"><?php echo e($book->title); ?></dd>
						<dt class="col-4">Kode</dt>
						<dd class="col-1">:</dd>
						<dd class="col-7"><?php echo e($book->code); ?></dd>
						<dt class="col-4">Penulis</dt>
						<dd class="col-1">:</dd>
						<dd class="col-7"><?php echo e($book->writer); ?></dd>
						<dt class="col-4">Penerbit</dt>
						<dd class="col-1">:</dd>
						<dd class="col-7"><?php echo e($book->publisher); ?></dd>
						<dt class="col-4">Tahun Terbit</dt>
						<dd class="col-1">:</dd>
						<dd class="col-7"><?php echo e($book->year); ?></dd>
						<dt class="col-4">Rak</dt>
						<dd class="col-1">:</dd>
						<dd class="col-7"><?php echo e($book->rack->name); ?></dd>
						<dt class="col-4">Status</dt>
						<dd class="col-1">:</dd>
						<dd class="col-7"><?php echo $book->statusBadge; ?></dd>
					</dl>
				</div>
				<div class="card-footer">
					<a href="<?php echo e(route('book.edit', $book->id)); ?>" class="btn btn-primary">Edit</a>
					<a href="<?php echo e(route('book.index')); ?>" class="btn btn-secondary">Kembali</a>
				</div>
			</div>
		</div>
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YOFAN\Desktop\front-end\perpus\resources\views/book/show.blade.php ENDPATH**/ ?>