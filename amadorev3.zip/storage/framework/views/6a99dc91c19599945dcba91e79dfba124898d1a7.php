<!DOCTYPE html>
<html lang="en">

<head>

  <title>Login</title>

  <?php echo $__env->make('_includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body class="bg-gradient-primary">

  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-6 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <div class="p-5">
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">Selamat Datang</h1>
              </div>
              
              <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('auth.login', [])->html();
} elseif ($_instance->childHasBeenRendered('p6oNw1c')) {
    $componentId = $_instance->getRenderedChildComponentId('p6oNw1c');
    $componentTag = $_instance->getRenderedChildComponentTagName('p6oNw1c');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('p6oNw1c');
} else {
    $response = \Livewire\Livewire::mount('auth.login', []);
    $html = $response->html();
    $_instance->logRenderedChild('p6oNw1c', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            </div>
          </div>
        </div>

      </div>

    </div>

  </div>

  <?php echo $__env->make('_includes.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\Users\YOFAN\Desktop\PA\amado\resources\views/auth/login.blade.php ENDPATH**/ ?>