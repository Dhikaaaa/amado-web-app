<div>
	
	<?php if($isOpen): ?>
		<div class="modal backdrop d-block">
		<div class="modal-backdrop" style="background: rgba(0,0,0,.5);">
		<div class="modal-dialog">
		<div class="modal-content">
		<form wire:submit.prevent="update">
			<div class="modal-header">
				<h5 class="modal-title">Edit Data</h5>
				<button type="button" class="close" wire:click="$set('isOpen', false)">&times;</button>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label>Nama</label>
					<input type="text" class="form-control <?php $__errorArgs = ['rack.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="rack.name" placeholder="Nama" autofocus>

					<?php $__errorArgs = ['rack.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback"><?php echo e($message); ?></span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>
			<div class="modal-footer">
				<button class="btn btn-primary shadow" type="submit">Edit</button>
				<button type="button" class="btn btn-secondary shadow" wire:click="$set('isOpen', false)">Batal</button>
			</div>
		</form>
		</div>
		</div>
		</div>
		</div>
	<?php endif; ?>

</div><?php /**PATH C:\Users\YOFAN\Desktop\PA\amado\resources\views/livewire/rack/edit.blade.php ENDPATH**/ ?>