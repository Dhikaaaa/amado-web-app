

<?php $__env->startSection('title', 'Data Pasien'); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <span><?php echo e(session('success')); ?></span>
            <button class="close" data-dismiss="alert">&times;</button>
        </div>
    <?php endif; ?>

    <div id="alert"></div>

    <div class="card shadow">
        <div class="card-header py-2 d-flex justify-content-between align-items-center">
            <h2 class="h6 m-0 font-weight-bold text-primary">Rekam Medis</h2>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-bordered" width="100%">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Pasien</th>
                            <th>Nilai Spo2</th>
                            <th>Status Pasien</th>
                            <th>Terakhir Diperbaharui</th>
                            <th>Detail</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('sbadmin/vendor/datatables/dataTables.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('sbadmin/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('sbadmin/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <script>
        const ajaxUrl = '<?php echo e(route('record.datatables')); ?>'
        const deleteUrl = '<?php echo e(route('record.destroy', ':id')); ?>'
        const csrf = '<?php echo e(csrf_token()); ?>'

    </script>

    <script src="<?php echo e(asset('js/record.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YOFAN\Desktop\PA\amado\resources\views/record/medical-record.blade.php ENDPATH**/ ?>