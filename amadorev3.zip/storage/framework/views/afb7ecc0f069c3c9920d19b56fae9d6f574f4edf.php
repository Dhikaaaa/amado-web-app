

<?php $__env->startSection('title', 'Rak'); ?>

<?php $__env->startSection('content'); ?>
	
	<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('rack.data', [])->html();
} elseif ($_instance->childHasBeenRendered('DD9CcWN')) {
    $componentId = $_instance->getRenderedChildComponentId('DD9CcWN');
    $componentTag = $_instance->getRenderedChildComponentTagName('DD9CcWN');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('DD9CcWN');
} else {
    $response = \Livewire\Livewire::mount('rack.data', []);
    $html = $response->html();
    $_instance->logRenderedChild('DD9CcWN', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YOFAN\Desktop\front-end\perpus\resources\views/rack.blade.php ENDPATH**/ ?>