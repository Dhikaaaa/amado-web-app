<div class="row">

	<div class="col-sm-4 mb-4">
		<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('rack.create', [])->html();
} elseif ($_instance->childHasBeenRendered('p6YeRm0')) {
    $componentId = $_instance->getRenderedChildComponentId('p6YeRm0');
    $componentTag = $_instance->getRenderedChildComponentTagName('p6YeRm0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('p6YeRm0');
} else {
    $response = \Livewire\Livewire::mount('rack.create', []);
    $html = $response->html();
    $_instance->logRenderedChild('p6YeRm0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
	</div>
	<div class="col-sm-8">
		<?php if(session()->has('success')): ?>
			<div class="alert alert-success alert-dismissible">
				<span><?php echo e(session('success')); ?></span>
				<button class="close" data-dismiss="alert">&times;</button>
			</div>
		<?php endif; ?>
		<div class="card shadow">
			<div class="card-header py-3">
				<h2 class="card-title h6 font-weight-bold text-primary m-0">Data Rak</h2>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>No</th>
								<th>Nama Rak</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
							<?php $__empty_1 = true; $__currentLoopData = $racks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<tr>
									<td><?php echo e($loop->iteration); ?></td>
									<td><?php echo e($rack->name); ?></td>
									<td>
										<button class="btn btn-success btn-sm" wire:click="$emit('edit', <?php echo e($rack->id); ?>)"><i class="fa fa-edit"></i></button>
										<button class="btn btn-danger btn-sm" onclick="remove()" wire:click="$emit('delete', <?php echo e($rack->id); ?>)"><i class="fa fa-trash"></i></button>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<tr>
									<td colspan="3" align="center">Kosong</td>
								</tr>
							<?php endif; ?>
						</tbody>
					</table>
				</div>
				<?php echo e($racks->links()); ?>

			</div>
		</div>
	</div>

	<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('rack.edit', [])->html();
} elseif ($_instance->childHasBeenRendered('9h65hTu')) {
    $componentId = $_instance->getRenderedChildComponentId('9h65hTu');
    $componentTag = $_instance->getRenderedChildComponentTagName('9h65hTu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9h65hTu');
} else {
    $response = \Livewire\Livewire::mount('rack.edit', []);
    $html = $response->html();
    $_instance->logRenderedChild('9h65hTu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

</div>

<?php $__env->startPush('js'); ?>
	<script>
		const remove = function () {
			return confirm('Yakin hapus data ini?') || event.stopImmediatePropagation()
		}
	</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Users\YOFAN\Desktop\PA\amado\resources\views/livewire/rack/data.blade.php ENDPATH**/ ?>