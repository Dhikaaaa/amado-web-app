<form wire:submit.prevent="search">
	<?php echo csrf_field(); ?>
	<div class="card-header py-3">
		<h2 class="h6 m-0 font-weight-bold text-primary">Pengembalian Buku</h2>
	</div>
	<div class="card-body">
		<div class="form-group">
			<label>Kode Buku</label>
			<input type="text" class="form-control <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="code" placeholder="Masukan Kode Buku" autofocus>

			<?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				<span class="invalid-feedback"><?php echo e($message); ?></span>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
		<button class="btn btn-primary shadow" type="submit">Cari</button>
	</div>
</form><?php /**PATH C:\Users\YOFAN\Desktop\front-end\perpus\resources\views/livewire/loan/return-search.blade.php ENDPATH**/ ?>