

<?php $__env->startSection('title', 'Perpanjangan Buku'); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="row">
		<div class="col-sm-5 mb-4">
			<div class="card shadow">
				<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('loan.extend-search', [])->html();
} elseif ($_instance->childHasBeenRendered('DOGCqzJ')) {
    $componentId = $_instance->getRenderedChildComponentId('DOGCqzJ');
    $componentTag = $_instance->getRenderedChildComponentTagName('DOGCqzJ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('DOGCqzJ');
} else {
    $response = \Livewire\Livewire::mount('loan.extend-search', []);
    $html = $response->html();
    $_instance->logRenderedChild('DOGCqzJ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
			</div>
		</div>
		<div class="col-sm-7">
			<div class="card shadow">
				<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('loan.extend-form', [])->html();
} elseif ($_instance->childHasBeenRendered('AWHLmlZ')) {
    $componentId = $_instance->getRenderedChildComponentId('AWHLmlZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('AWHLmlZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AWHLmlZ');
} else {
    $response = \Livewire\Livewire::mount('loan.extend-form', []);
    $html = $response->html();
    $_instance->logRenderedChild('AWHLmlZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
			</div>
		</div>
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YOFAN\Desktop\front-end\perpus\resources\views/loan/extend.blade.php ENDPATH**/ ?>