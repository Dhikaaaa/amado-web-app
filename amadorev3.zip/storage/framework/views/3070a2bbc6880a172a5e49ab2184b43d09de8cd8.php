

<?php $__env->startSection('title', 'Pengaturan'); ?>

<?php $__env->startSection('content'); ?>
	
	<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('setting', [])->html();
} elseif ($_instance->childHasBeenRendered('G8bUa6M')) {
    $componentId = $_instance->getRenderedChildComponentId('G8bUa6M');
    $componentTag = $_instance->getRenderedChildComponentTagName('G8bUa6M');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('G8bUa6M');
} else {
    $response = \Livewire\Livewire::mount('setting', []);
    $html = $response->html();
    $_instance->logRenderedChild('G8bUa6M', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YOFAN\Desktop\front-end\perpus\resources\views/setting.blade.php ENDPATH**/ ?>