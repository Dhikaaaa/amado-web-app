<?php

/**
 * * Topic ID
 */
const ID_TOPIC_PULSE_MONITORING = 1;
const ID_TOPIC_PULSE_RESULT = 2;


/**
 * * General User ID
 */
const ID_GENERAL_NEW_USER = 3;
