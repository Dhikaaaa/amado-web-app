@extends('_layouts.app')

@section('title', 'Pengaturan')

@section('content')
	
	<livewire:setting />

@endsection