@extends('_layouts.app')

@section('title', 'Rak')

@section('content')
	
	<livewire:rack.data />

@endsection