<?php return array (
  'auth.login' => 'App\\Http\\Livewire\\Auth\\Login',
  'loan.extend-form' => 'App\\Http\\Livewire\\Loan\\ExtendForm',
  'loan.extend-search' => 'App\\Http\\Livewire\\Loan\\ExtendSearch',
  'loan.return-form' => 'App\\Http\\Livewire\\Loan\\ReturnForm',
  'loan.return-search' => 'App\\Http\\Livewire\\Loan\\ReturnSearch',
  'rack.create' => 'App\\Http\\Livewire\\Rack\\Create',
  'rack.data' => 'App\\Http\\Livewire\\Rack\\Data',
  'rack.edit' => 'App\\Http\\Livewire\\Rack\\Edit',
  'setting' => 'App\\Http\\Livewire\\Setting',
);